import ForgotPasswordForm from '@/components/auth/forgot-password/forgot-password-form'

export default function Page() {
  return <ForgotPasswordForm />
}
