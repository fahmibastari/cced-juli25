import News from '@/components/blog/news/News'

export default function Page() {
  return <News />
}
