import Article from '@/components/blog/article/Article'

export default function Page() {
  return <Article />
}
