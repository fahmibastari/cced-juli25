import HomePage from '@/components/landing/HomePage'

export default function Home() {
  return <HomePage />
}
