import { getJobs } from '@/actions/admin-action'
import JobsControl from '@/components/admin/jobs-control-admin'
import RoleGate from '@/components/auth/role-gate'
import { Role } from '@prisma/client'

export default async function Page() {
  const jobs = await getJobs()
  return (
    <RoleGate accessRole={Role.ADMIN}>
      <JobsControl jobs={jobs || []} />
    </RoleGate>
  )
}
