export default function WaitingForVerificationPage() {
    return (
      <div className="flex items-center justify-center min-h-screen text-center">
        <div>
          <h1 className="text-3xl font-bold mb-4">Waiting for Verification</h1>
        </div>
      </div>
    )
  }